/* order.js - fitur pesan untuk pelanggan. Berjalan di atas app.js tanpa mengubahnya. */
(() => {
  const CONFIG = {
    ORDER_URL: '/api/orders',   // endpoint pesanan (lihat routes/orders.js)
    WA_NUMBER: ''    // nomor kasir format '6281234567890' untuk tombol kirim via WhatsApp
  };
  const $ = s => document.querySelector(s);
  const rp = n => 'Rp ' + n.toLocaleString('id-ID');
  const num = t => parseInt(String(t).replace(/\D/g, ''), 10) || 0;
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  let cart = {}; // kunci: nama menu

  /* ---- Mode Pelanggan / Admin ---- */
  const bC = $('#modeCustomer'), bA = $('#modeAdmin'), pinModal = $('#pinModal'), pinInput = $('#pinInput');
  function setAdmin(on) {
    document.body.classList.toggle('admin', on);
    bC.setAttribute('aria-pressed', !on); bA.setAttribute('aria-pressed', on);
  }
  const getPin = () => sessionStorage.getItem('rn_pin') || '';
  async function login(pin) {
    try { return (await fetch(CONFIG.ORDER_URL + '/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pin }) })).ok; }
    catch (e) { return false; }
  }
  bC.addEventListener('click', () => { setAdmin(false); clearInterval(poll); sessionStorage.removeItem('rn_pin'); });
  bA.addEventListener('click', () => {
    if (document.body.classList.contains('admin')) return;
    $('#pinErr').classList.add('hidden'); pinInput.value = ''; pinModal.classList.remove('hidden'); setTimeout(() => pinInput.focus(), 50);
  });
  $('#pinClose').addEventListener('click', () => pinModal.classList.add('hidden'));
  pinModal.addEventListener('click', e => { if (e.target === pinModal) pinModal.classList.add('hidden'); });
  $('#pinForm').addEventListener('submit', async e => {
    e.preventDefault();
    const pin = pinInput.value;
    if (await login(pin)) { sessionStorage.setItem('rn_pin', pin); pinModal.classList.add('hidden'); setAdmin(true); startPolling(); }
    else { $('#pinErr').classList.remove('hidden'); pinInput.select(); }
  });
  setAdmin(false);
  if (getPin()) login(getPin()).then(ok => { if (ok) { setAdmin(true); startPolling(); } });

  /* ---- Nomor meja dari URL: ?meja=12 ---- */
  const meja = new URLSearchParams(location.search).get('meja');
  if (meja) { const t = $('#mejaTag'); t.textContent = 'Meja ' + meja; t.classList.remove('hidden'); }

  /* ---- Toast ---- */
  function toast(msg) {
    const el = document.createElement('div');
    el.className = 'toast success';
    el.innerHTML = '<span class="toast-icon">🛒</span><span class="toast-message">' + esc(msg) + '</span>';
    $('#toastContainer').appendChild(el);
    setTimeout(() => el.remove(), 1800);
  }

  /* ---- Baca data dari kartu ---- */
  function readCard(card) {
    const img = card.querySelector('.card-img');
    return {
      name: card.querySelector('.card-title')?.textContent.trim() || '',
      price: num(card.querySelector('.card-price')?.textContent),
      img: img ? img.getAttribute('src') : '',
      out: !!card.querySelector('.status-habis')
    };
  }

  /* ---- Kontrol + / stepper di tiap kartu ---- */
  const grid = $('#menuGrid');
  const obs = new MutationObserver(enhance);
  function ctlHTML(it) {
    if (it.out) return '<button class="add-btn" disabled>Habis</button>';
    const q = cart[it.name]?.qty || 0;
    const k = esc(it.name);
    return q
      ? `<span class="stp"><button data-o="-1" data-k="${k}" aria-label="Kurangi ${k}">−</button><span>${q}</span><button data-o="1" data-k="${k}" aria-label="Tambah ${k}">+</button></span>`
      : `<button class="add-btn" data-o="1" data-k="${k}" aria-label="Pesan ${k}">+ Pesan</button>`;
  }
  function enhance() {
    obs.disconnect();
    grid.querySelectorAll('.menu-card').forEach(card => {
      const footer = card.querySelector('.card-footer'); if (!footer) return;
      let ctl = footer.querySelector('.order-ctl');
      if (!ctl) { ctl = document.createElement('div'); ctl.className = 'order-ctl'; footer.appendChild(ctl); }
      const it = readCard(card);
      ctl.innerHTML = ctlHTML(it);
      ctl._item = it;
    });
    obs.observe(grid, { childList: true, subtree: true });
  }
  obs.observe(grid, { childList: true, subtree: true });
  enhance();

  /* ---- Logika keranjang ---- */
  function find(name) {
    for (const c of grid.querySelectorAll('.menu-card')) { const it = readCard(c); if (it.name === name) return it; }
    return null;
  }
  function change(item, d) {
    if (!item || item.out) return;
    const c = cart[item.name] || (cart[item.name] = { ...item, qty: 0, note: '' });
    c.qty += d;
    if (c.qty <= 0) delete cart[item.name]; else if (d > 0) toast(item.name + ' masuk pesanan');
    enhance(); updateBar();
    if (!$('#cartModal').classList.contains('hidden')) renderCart();
  }
  function totals() {
    const v = Object.values(cart);
    return { n: v.reduce((a, c) => a + c.qty, 0), t: v.reduce((a, c) => a + c.qty * c.price, 0) };
  }
  function updateBar() {
    const { n, t } = totals();
    $('#cartCount').textContent = n + ' item';
    $('#cartTotal').textContent = rp(t);
    $('#cartBar').classList.toggle('off', n === 0);
  }

  /* ---- Modal pesanan ---- */
  const modal = $('#cartModal'), body = $('#cartBody');
  const open = () => { renderCart(); modal.classList.remove('hidden'); };
  const close = () => modal.classList.add('hidden');
  function renderCart(err) {
    const keep = { n: $('#cName')?.value || '', t: $('#cTable')?.value ?? (meja || '') };
    const items = Object.values(cart);
    if (!items.length) { close(); return; }
    const { t } = totals();
    body.innerHTML = `<div class="modal-header"><h3 class="modal-title">Pesananmu 🛒</h3><button class="modal-close" data-x="close" aria-label="Tutup">&times;</button></div>
    <div class="modal-body">
      ${items.map(c => `<div class="cart-item">
        <div class="cart-thumb" ${c.img ? `style="background-image:url('${esc(c.img)}')"` : ''}>${c.img ? '' : '🍽️'}</div>
        <div class="cart-info"><b>${esc(c.name)}</b><small>${rp(c.price * c.qty)}</small>
          <input class="cart-note" data-note="${esc(c.name)}" value="${esc(c.note)}" placeholder="Catatan, mis. tanpa pedas" aria-label="Catatan untuk ${esc(c.name)}"></div>
        <span class="stp"><button data-o="-1" data-k="${esc(c.name)}" aria-label="Kurangi">−</button><span>${c.qty}</span><button data-o="1" data-k="${esc(c.name)}" aria-label="Tambah">+</button></span>
      </div>`).join('')}
      <div class="cart-fields">
        <div><label for="cName">Nama kamu</label><input id="cName" class="${err ? 'err' : ''}" placeholder="Misal: Dinda" value="${esc(keep.n)}"></div>
        <div><label for="cTable">No. meja</label><input id="cTable" inputmode="numeric" class="${err ? 'err' : ''}" placeholder="12" value="${esc(keep.t)}"></div>
      </div>
      ${err ? `<p class="cart-error">${err}</p>` : ''}
      <div class="cart-total"><span>Total</span><span>${rp(t)}</span></div>
      <button class="cart-cta" data-x="send">Kirim pesanan</button>
      <button class="cart-cta alt" data-x="close">+ Tambah menu lagi</button>
    </div>`;
  }
  async function send() {
    const name = $('#cName').value.trim(), table = $('#cTable').value.trim();
    if (!name || !table) { renderCart('Isi nama dan nomor mejamu dulu ya.'); $('#cName').value = name; $('#cTable').value = table; return; }
    const items = Object.values(cart), { t } = totals();
    const payload = { nama: name, meja: table, total: t, items: items.map(c => ({ nama: c.name, jumlah: c.qty, harga: c.price, catatan: c.note })) };
    let no, id;
    try {
      const r = await fetch(CONFIG.ORDER_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      if (!r.ok) throw new Error(r.status);
      ({ nomor: no, id } = await r.json());
    } catch (e) { renderCart(e.message === '404' ? 'Fitur pesanan belum aktif di server (routes/orders.js belum dipasang).' : 'Pesanan gagal terkirim. Cek koneksi lalu coba lagi.'); $('#cName').value = name; $('#cTable').value = table; return; }
    const text = `Pesanan ${no}\nNama: ${name} (Meja ${table})\n` + payload.items.map(i => `- ${i.jumlah}x ${i.nama}${i.catatan ? ' (' + i.catatan + ')' : ''}`).join('\n') + `\nTotal: ${rp(t)}`;
    const wa = CONFIG.WA_NUMBER ? `https://wa.me/${CONFIG.WA_NUMBER}?text=${encodeURIComponent(text)}` : '';
    cart = {}; enhance(); updateBar();
    body.innerHTML = `<div class="cart-ok"><div class="big">🎉</div><h3>Pesanan terkirim!</h3><span class="cart-no">${no}</span><div class="cart-status" id="orderStatus">⏳ Menunggu dikonfirmasi dapur</div>
      <p>Makasih, ${esc(name)}! Pesananmu lagi disiapkan dan diantar ke meja ${esc(table)}.</p>
      ${wa ? `<a class="cart-cta" href="${wa}" target="_blank" rel="noopener">Kirim ke WhatsApp kasir</a>` : ''}
      <button class="cart-cta alt" data-x="close">Pesan lagi</button></div>`;
    trackOrder(id);
  }

  /* ---- Event ---- */
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-o]');
    if (b) {
      const name = b.dataset.k, d = +b.dataset.o;
      change(cart[name] || b.closest('.order-ctl')?._item || find(name), d);
      return;
    }
    const x = e.target.closest('[data-x]')?.dataset.x;
    if (x === 'close') close(); else if (x === 'send') send();
    else if (e.target.closest('#btnOpenCart')) open();
    else if (e.target === modal) close();
    else if (e.target.closest('#btnOrderFromDetail')) {
      const hero = $('#detailHeroImage').style.backgroundImage.replace(/^url\(["']?|["']?\)$/g, '');
      change({ name: $('#detailNama').textContent.trim(), price: num($('#detailHarga').textContent), img: hero, out: /habis/i.test($('#detailStatus').textContent) }, 1);
    }
  });
  document.addEventListener('input', e => { const n = e.target.dataset?.note; if (n && cart[n]) cart[n].note = e.target.value; });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { close(); pinModal.classList.add('hidden'); } });

  /* ---- Pelanggan: lacak status pesanan ---- */
  let tr;
  function trackOrder(id) {
    clearInterval(tr);
    const tick = async () => {
      const el = $('#orderStatus'); if (!el) { clearInterval(tr); return; }
      try {
        const r = await fetch(`${CONFIG.ORDER_URL}/${id}/status`); if (!r.ok) return;
        const { status } = await r.json();
        el.textContent = { baru: '⏳ Menunggu dikonfirmasi dapur', diproses: '👩‍🍳 Sedang disiapkan', selesai: '✅ Pesanan siap, selamat makan!' }[status] || '';
        if (status === 'selesai') clearInterval(tr);
      } catch (e) {}
    };
    tr = setInterval(tick, 6000); tick();
  }

  /* ---- Admin: daftar pesanan ---- */
  let orders = [], poll, lastNew = 0;
  const hdr = () => ({ 'Content-Type': 'application/json', 'x-admin-pin': getPin() });
  const oModal = $('#ordersModal'), oBody = $('#ordersBody');
  async function loadOrders() {
    try {
      const r = await fetch(CONFIG.ORDER_URL, { headers: hdr() }); if (!r.ok) return;
      orders = await r.json();
      const nb = orders.filter(o => o.status === 'baru').length;
      const badge = $('#ordersBadge'); badge.textContent = nb; badge.classList.toggle('hidden', !nb);
      if (nb > lastNew) toast('Ada pesanan baru!');
      lastNew = nb;
      if (!oModal.classList.contains('hidden')) renderOrders();
    } catch (e) {}
  }
  function startPolling() { clearInterval(poll); lastNew = 0; loadOrders(); poll = setInterval(loadOrders, 8000); }
  const NEXT = { baru: ['diproses', 'Proses'], diproses: ['selesai', 'Selesai'] };
  function renderOrders() {
    const jam = s => new Date(s).toLocaleString('id-ID', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' });
    oBody.innerHTML = `<div class="modal-header"><h3 class="modal-title">Pesanan masuk</h3><button class="modal-close" data-x="oclose" aria-label="Tutup">&times;</button></div>
    <div class="modal-body">${orders.length ? orders.map(o => `<article class="ord s-${o.status}">
      <div class="ord-h"><b>${esc(o.nomor)} · Meja ${esc(o.meja)}</b><span class="pill">${o.status}</span></div>
      <div class="ord-meta">${esc(o.nama)} · ${jam(o.dibuat)}</div>
      <ul>${o.items.map(i => `<li>${i.jumlah}× ${esc(i.nama)}${i.catatan ? ` <small>(${esc(i.catatan)})</small>` : ''}</li>`).join('')}</ul>
      <div class="ord-f"><b>${rp(o.total)}</b><span>
        ${NEXT[o.status] ? `<button class="btn btn-primary" data-ost="${o.id}:${NEXT[o.status][0]}">${NEXT[o.status][1]}</button>` : ''}
        <button class="btn btn-secondary" data-odel="${o.id}" aria-label="Hapus pesanan">Hapus</button></span></div>
    </article>`).join('') : '<p class="cart-ok">Belum ada pesanan masuk.</p>'}</div>`;
  }
  document.addEventListener('click', async e => {
    if (e.target.closest('#btnOrders')) { renderOrders(); oModal.classList.remove('hidden'); loadOrders(); return; }
    if (e.target === oModal || e.target.closest('[data-x="oclose"]')) { oModal.classList.add('hidden'); return; }
    const st = e.target.closest('[data-ost]')?.dataset.ost, del = e.target.closest('[data-odel]')?.dataset.odel;
    if (st) { const [id, status] = st.split(':'); await fetch(`${CONFIG.ORDER_URL}/${id}`, { method: 'PATCH', headers: hdr(), body: JSON.stringify({ status }) }); loadOrders(); }
    else if (del && confirm('Hapus pesanan ini?')) { await fetch(`${CONFIG.ORDER_URL}/${del}`, { method: 'DELETE', headers: hdr() }); loadOrders(); }
  });
window.__orderReady = true;
})();