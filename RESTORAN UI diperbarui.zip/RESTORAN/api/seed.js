/**
 * seed.js (versi baru)
 *
 * LANGKAH SEBELUM MENJALANKAN:
 * 1. Ganti nama file seed.js yang LAMA menjadi seed-lama.js (letakkan di folder yang sama).
 * 2. Simpan file ini sebagai seed.js.
 * 3. Ubah KONTAK di bawah dengan emailmu (diminta Wikimedia saat mengambil gambar).
 * 4. Jalankan: node seed.js   (butuh Node.js 18 ke atas dan koneksi internet)
 *
 * Yang berubah:
 * - Kategori Makanan Utama, Minuman, dan Dessert diganti total dengan menu khas Indonesia.
 * - Kategori lain (Seafood, Mie & Pasta, Steak & Western, Cemilan) diambil apa adanya dari seed-lama.js.
 * - Gambar dicari otomatis dari Wikimedia Commons memakai kata kunci tiap menu (field "cari"),
 *   lalu disimpan di gambar-cache.json supaya tidak dicari ulang.
 * - Mau pakai foto sendiri? Isi field "gambar" di menu itu, maka pencarian otomatis dilewati.
 */

const fs = require("fs");
const path = require("path");
const db = require("./config/database");
const initDatabase = require("./config/initDb");
const { menuItems: menuLama } = require("./seed-lama");

const KONTAK = "email-kamu@contoh.com";
const KATEGORI_DIGANTI = ["Makanan Utama", "Minuman", "Dessert"];
const URUTAN_KATEGORI = ["Makanan Utama", "Seafood", "Mie & Pasta", "Steak & Western", "Cemilan", "Dessert", "Minuman"];
const CACHE_FILE = path.join(__dirname, "gambar-cache.json");

const MU = "Makanan Utama", MN = "Minuman", DS = "Dessert";
// item(kategori, nama, harga, kata kunci pencarian gambar, deskripsi)
const item = (kategori, nama, harga, cari, deskripsi) => ({ kategori, nama, harga, cari, deskripsi, status: "tersedia" });

const menuBaru = [
    // --- MAKANAN UTAMA (25) ---
    item(MU, "Rendang Sapi Padang", 45000, "rendang", "Daging sapi dimasak berjam-jam dengan santan dan rempah sampai empuk dan pekat bumbunya."),
    item(MU, "Gudeg Jogja Komplit", 32000, "gudeg", "Nangka muda manis gurih, disajikan dengan ayam, telur pindang, krecek, dan sambal goreng."),
    item(MU, "Soto Ayam Lamongan", 24000, "soto ayam", "Kuah kuning bening dengan suwiran ayam, koya gurih, dan perasan jeruk nipis."),
    item(MU, "Rawon Daging Surabaya", 34000, "rawon", "Sup daging berkuah hitam dari kluwek, dimakan dengan tauge pendek, telur asin, dan sambal."),
    item(MU, "Nasi Pecel Madiun", 20000, "nasi pecel", "Sayur rebus disiram sambal kacang pedas manis, ditemani rempeyek dan tempe goreng."),
    item(MU, "Ayam Bakar Taliwang", 38000, "ayam taliwang", "Ayam kampung bakar dengan bumbu cabai khas Lombok yang pedas dan harum."),
    item(MU, "Ayam Goreng Lengkuas", 28000, "ayam goreng lengkuas", "Ayam goreng gurih dengan serundeng lengkuas renyah di atasnya."),
    item(MU, "Gulai Kepala Ikan", 42000, "gulai kepala ikan", "Kepala ikan kakap dalam kuah gulai kuning yang kaya rempah."),
    item(MU, "Sate Ayam Madura", 28000, "sate ayam madura", "Sepuluh tusuk sate ayam bakar dengan bumbu kacang kental dan irisan bawang merah."),
    item(MU, "Sate Maranggi Purwakarta", 35000, "sate maranggi", "Sate sapi yang direndam bumbu ketumbar, disantap dengan sambal tomat dan acar."),
    item(MU, "Nasi Campur Bali", 36000, "nasi campur bali", "Nasi dengan ayam suwir, sate lilit, urap, telur, dan sambal matah."),
    item(MU, "Bebek Goreng Madura", 40000, "bebek goreng", "Bebek empuk berbumbu rempah, digoreng garing dan disajikan dengan sambal pencit."),
    item(MU, "Pempek Kapal Selam Palembang", 30000, "pempek kapal selam", "Pempek ikan isi telur dengan kuah cuko asam manis pedas."),
    item(MU, "Soto Betawi", 32000, "soto betawi", "Kuah santan susu dengan daging sapi, jeroan, kentang, dan emping."),
    item(MU, "Nasi Kuning Tumpeng Mini", 30000, "nasi kuning", "Nasi kuning gurih dengan telur dadar, abon, perkedel, dan sambal kentang."),
    item(MU, "Ayam Rica-Rica Manado", 34000, "ayam rica-rica", "Ayam dengan bumbu cabai, kemangi, dan jeruk purut yang segar dan pedas."),
    item(MU, "Nasi Liwet Sunda", 28000, "nasi liwet", "Nasi pulen dimasak dengan serai dan daun salam, ditemani ikan asin, lalapan, dan sambal dadak."),
    item(MU, "Gado-Gado Betawi", 22000, "gado-gado", "Sayuran, tahu, tempe, dan lontong dengan saus kacang kental dan kerupuk."),
    item(MU, "Lontong Opor Ayam", 26000, "opor ayam", "Lontong dengan opor ayam kuah santan lembut dan sambal goreng ati."),
    item(MU, "Empal Gentong Cirebon", 33000, "empal gentong", "Daging sapi dalam kuah santan kuning, dimasak di gentong tanah liat dengan kayu bakar."),
    item(MU, "Coto Makassar", 32000, "coto makassar", "Sup daging dan jeroan dengan kuah kacang gurih, dimakan bersama ketupat."),
    item(MU, "Tongseng Kambing Solo", 42000, "tongseng", "Kambing muda dengan kol dan tomat dalam kuah kecap pedas manis."),
    item(MU, "Sop Buntut Bakar", 55000, "sop buntut", "Buntut sapi bakar disajikan dengan kuah sop bening, wortel, dan kentang."),
    item(MU, "Nasi Rames Warung", 18000, "nasi rames", "Nasi dengan sayur lodeh, orek tempe, telur balado, dan kerupuk."),
    item(MU, "Nasi Bakar Ayam Kemangi", 27000, "nasi bakar", "Nasi berisi ayam suwir dan kemangi, dibungkus daun pisang lalu dibakar harum."),

    // --- MINUMAN (18) ---
    item(MN, "Es Teh Manis", 5000, "es teh manis", "Teh seduh pekat dengan gula, disajikan dingin dengan banyak es."),
    item(MN, "Es Jeruk Peras", 10000, "es jeruk peras", "Jeruk peras segar dengan sedikit gula dan es batu."),
    item(MN, "Wedang Jahe Merah", 12000, "wedang jahe", "Jahe merah rebus dengan gula aren, hangat dan menenangkan tenggorokan."),
    item(MN, "Wedang Uwuh", 14000, "wedang uwuh", "Minuman rempah khas Yogyakarta dari secang, jahe, cengkih, dan kayu manis."),
    item(MN, "Bandrek Hangat", 13000, "bandrek", "Minuman jahe, gula merah, dan rempah khas Sunda yang menghangatkan badan."),
    item(MN, "Bajigur", 13000, "bajigur", "Santan hangat dengan gula aren dan jahe, ditemani kolang-kaling."),
    item(MN, "Sekoteng", 14000, "sekoteng", "Wedang jahe dengan kacang tanah, kacang hijau, roti tawar, dan pacar cina."),
    item(MN, "Jamu Kunyit Asam", 12000, "jamu kunyit asam", "Jamu kunyit, asam jawa, dan gula merah yang segar dan sedikit asam."),
    item(MN, "Jamu Beras Kencur", 12000, "jamu beras kencur", "Jamu manis dari beras, kencur, dan jahe, enak diminum dingin maupun hangat."),
    item(MN, "Es Kelapa Muda", 15000, "es kelapa muda", "Air dan daging kelapa muda dengan sirup gula dan es batu."),
    item(MN, "Es Cendol Dawet", 14000, "es cendol", "Cendol hijau kenyal dengan santan, gula aren cair, dan es serut."),
    item(MN, "Es Cincau Hijau", 12000, "es cincau", "Cincau hijau segar dengan sirup gula dan sedikit susu."),
    item(MN, "Es Doger", 16000, "es doger", "Es serut santan dengan tape, ketan hitam, roti, kacang, dan susu kental manis."),
    item(MN, "Kopi Tubruk", 10000, "kopi tubruk", "Kopi bubuk diseduh langsung di gelas, kental dan pekat, disajikan dengan gula terpisah."),
    item(MN, "Kopi Susu Gula Aren", 18000, "kopi susu gula aren", "Espresso, susu segar, dan gula aren dingin yang wangi dan seimbang."),
    item(MN, "Es Sirsak", 14000, "jus sirsak", "Sirsak segar diblender dengan gula dan es, asam manis dan lembut."),
    item(MN, "Es Temulawak", 12000, "temulawak minuman", "Minuman rempah temulawak yang segar dan ringan di perut."),
    item(MN, "Wedang Ronde", 15000, "wedang ronde", "Bola ketan berisi kacang dalam kuah jahe hangat dengan kolang-kaling."),

    // --- DESSERT (15) ---
    item(DS, "Klepon", 12000, "klepon", "Bola ketan hijau isi gula merah cair, digulung kelapa parut."),
    item(DS, "Es Teler", 20000, "es teler", "Alpukat, kelapa muda, dan nangka dengan santan manis dan es serut."),
    item(DS, "Es Campur", 18000, "es campur", "Aneka isian manis seperti cincau, kolang-kaling, dan tape dengan sirup dan susu."),
    item(DS, "Es Pisang Ijo Makassar", 20000, "es pisang ijo", "Pisang berbalut adonan hijau, disiram santan, sirup merah, dan es serut."),
    item(DS, "Kolak Pisang Ubi", 15000, "kolak pisang", "Pisang kepok dan ubi jalar dalam kuah santan gula aren yang hangat."),
    item(DS, "Bubur Sumsum", 12000, "bubur sumsum", "Bubur tepung beras lembut dengan siraman kuah gula merah."),
    item(DS, "Bubur Ketan Hitam", 14000, "bubur ketan hitam", "Ketan hitam dimasak manis dan disiram santan gurih."),
    item(DS, "Serabi Solo", 13000, "serabi", "Kue tepung beras dan kelapa yang dibakar tipis, disajikan dengan kuah kinca."),
    item(DS, "Dadar Gulung", 12000, "dadar gulung", "Dadar hijau pandan berisi kelapa dan gula merah."),
    item(DS, "Putu Ayu", 12000, "putu ayu", "Kue kukus lembut dengan taburan kelapa parut segar."),
    item(DS, "Kue Lapis Legit", 22000, "lapis legit", "Kue berlapis tipis beraroma mentega dan rempah, manis dan padat."),
    item(DS, "Onde-Onde", 12000, "onde-onde", "Bola tepung ketan berwijen yang renyah di luar, isi kacang hijau manis di dalam."),
    item(DS, "Lupis Gula Jawa", 13000, "lupis", "Ketan berbentuk silinder dengan kelapa parut dan sirup gula jawa."),
    item(DS, "Getuk Lindri", 11000, "getuk lindri", "Getuk singkong berwarna-warni yang lembut, ditaburi kelapa parut."),
    item(DS, "Es Selendang Mayang", 18000, "selendang mayang", "Agar-agar warna-warni dalam santan manis dan es serut khas Betawi.")
];

// ---------- Pencarian gambar otomatis (Wikimedia Commons) ----------
let cache = {};
try { cache = JSON.parse(fs.readFileSync(CACHE_FILE, "utf8")); } catch (e) { cache = {}; }

const tunggu = (ms) => new Promise((r) => setTimeout(r, ms));
const BUKAN_FOTO_MAKANAN = /map|logo|flag|diagram|poster|stamp|coat of arms|icon|chart|menu board/i;

async function cariGambar(kataKunci) {
    if (typeof fetch !== "function") {
        throw new Error("Node.js kamu terlalu lama. Gunakan Node 18 ke atas.");
    }
    const url = "https://commons.wikimedia.org/w/api.php?" + new URLSearchParams({
        action: "query",
        format: "json",
        generator: "search",
        gsrnamespace: "6",
        gsrlimit: "10",
        gsrsearch: `${kataKunci} filetype:bitmap`,
        prop: "imageinfo",
        iiprop: "url|mime|size",
        iiurlwidth: "600"
    });
    try {
        const res = await fetch(url, { headers: { "User-Agent": `AmbaRestoSeed/1.0 (${KONTAK})` } });
        if (!res.ok) return null;
        const data = await res.json();
        const halaman = Object.values((data.query && data.query.pages) || {}).sort((a, b) => a.index - b.index);
        for (const h of halaman) {
            const info = h.imageinfo && h.imageinfo[0];
            if (!info || info.mime !== "image/jpeg") continue;
            if (info.width < 400 || BUKAN_FOTO_MAKANAN.test(h.title)) continue;
            const link = info.thumburl || info.url;
            if (link && link.length <= 250) return link;   // aman untuk kolom VARCHAR(255)
        }
    } catch (e) {
        console.warn(`  (gagal mencari "${kataKunci}": ${e.message})`);
    }
    return null;
}

const placeholder = (nama) => `https://placehold.co/600x400/f1e9d8/2b2118?text=${encodeURIComponent(nama)}`;

async function siapkanGambar(daftar) {
    const gagal = [];
    for (const m of daftar) {
        if (m.gambar) continue;                      // foto manual dihormati
        if (!cache[m.cari]) {
            cache[m.cari] = await cariGambar(m.cari);
            fs.writeFileSync(CACHE_FILE, JSON.stringify(cache, null, 2));
            await tunggu(400);                       // sopan terhadap server Wikimedia
        }
        if (cache[m.cari]) {
            m.gambar = cache[m.cari];
        } else {
            m.gambar = placeholder(m.nama);
            gagal.push(m.nama);
        }
    }
    return gagal;
}

// ---------- Gabungkan menu ----------
const menuItems = [
    ...menuLama.filter((m) => !KATEGORI_DIGANTI.includes(m.kategori)),
    ...menuBaru
].sort((a, b) => URUTAN_KATEGORI.indexOf(a.kategori) - URUTAN_KATEGORI.indexOf(b.kategori));

async function seedDatabase() {
    try {
        console.log(`Menyiapkan ${menuItems.length} menu...`);
        await initDatabase();

        console.log("Mencari gambar yang sesuai dengan nama menu (bisa beberapa menit pada percobaan pertama)...");
        const gagal = await siapkanGambar(menuItems);
        if (gagal.length) {
            console.log(`⚠️  ${gagal.length} menu belum dapat foto, diberi gambar placeholder bertuliskan nama menu:`);
            gagal.forEach((n) => console.log(` - ${n}`));
            console.log("   Isi field \"gambar\" menu tersebut dengan URL foto sendiri, lalu jalankan ulang.");
        }

        const [[{ count }]] = await db.query("SELECT COUNT(*) as count FROM menu");
        console.log(`Jumlah menu di database saat ini: ${count}`);

        console.log("Mengosongkan tabel menu lalu memasukkan data baru...");
        await db.query("TRUNCATE TABLE menu");

        const insertQuery = `
            INSERT INTO menu (nama, kategori, harga, deskripsi, status, gambar)
            VALUES (?, ?, ?, ?, ?, ?)
        `;
        for (const m of menuItems) {
            await db.query(insertQuery, [m.nama, m.kategori, m.harga, m.deskripsi, m.status, m.gambar]);
        }

        const [[{ newCount }]] = await db.query("SELECT COUNT(*) as newCount FROM menu");
        console.log(`✅ Seeding selesai! Total menu di database: ${newCount}`);

        const [categories] = await db.query("SELECT kategori, COUNT(*) as total FROM menu GROUP BY kategori ORDER BY total DESC");
        console.log("Ringkasan kategori:");
        categories.forEach((c) => console.log(` - ${c.kategori}: ${c.total} menu`));
    } catch (error) {
        console.error("❌ Seeding gagal:", error);
        throw error;
    }
}

if (require.main === module) {
    seedDatabase()
        .then(() => process.exit(0))
        .catch(() => process.exit(1));
}

module.exports = { seedDatabase, menuItems };