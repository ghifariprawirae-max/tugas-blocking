<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Buku</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-8">
    <div class="max-w-4xl mx-auto bg-white p-6 rounded-lg shadow-md">
        
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold text-blue-600">Daftar Buku Perpustakaan</h1>
            <a href="/books/add" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded-lg shadow">
                + Tambah Buku
            </a>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse border border-gray-200">
                <thead>
                    <tr class="bg-gray-100 text-gray-700">
                        <th class="p-3 border">Judul</th>
                        <th class="p-3 border">Penulis</th>
                        <th class="p-3 border">Penerbit</th>
                        <th class="p-3 border">Tahun</th>
                        <th class="p-3 border text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($books as $book)
                    <tr class="hover:bg-gray-50">
                        <td class="p-3 border font-semibold text-gray-800">{{ $book->title }}</td>
                        <td class="p-3 border text-gray-600">{{ $book->author }}</td>
                        <td class="p-3 border text-gray-600">{{ $book->publisher }}</td>
                        <td class="p-3 border text-gray-600">{{ $book->year }}</td>
                        <td class="p-3 border text-center space-x-2">
                            <a href="/books/edit/{{ $book->id }}" class="bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 rounded text-sm font-medium">
                                Edit
                            </a>
                            <a href="/books/delete/{{ $book->id }}" onclick="return confirm('Yakin ingin menghapus buku ini?')" class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-sm font-medium">
                                Hapus
                            </a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

    </div>
</body>
</html>