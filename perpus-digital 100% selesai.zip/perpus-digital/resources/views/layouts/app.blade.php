<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Perpustakaan Digital')</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-8">
    <div class="max-w-4xl mx-auto">
<nav>
    <a href="/" class="mr-4 hover:underline font-semibold">Beranda</a>
    <a href="/about" class="mr-4 hover:underline font-semibold">Tentang</a>
    <a href="/contact" class="mr-4 hover:underline font-semibold">Kontak</a>
    <a href="/books" class="hover:underline font-semibold">Daftar Buku</a>
</nav>
        @yield('content')
    </div>
</body>
</html>