<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Buku</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-8">
    <div class="max-w-md mx-auto bg-white p-6 rounded-lg shadow-md">
        <h2 class="text-xl font-bold mb-4 text-yellow-600">Edit Data Buku</h2>
        
        <form action="/books/update/{{ $book->id }}" method="POST" class="space-y-4">
            @csrf
            <div>
                <label class="block mb-1 font-semibold text-gray-700">Judul Buku</label>
                <input type="text" name="title" value="{{ $book->title }}" required class="w-full border p-2 rounded focus:outline-yellow-500">
            </div>
            <div>
                <label class="block mb-1 font-semibold text-gray-700">Penulis</label>
                <input type="text" name="author" value="{{ $book->author }}" required class="w-full border p-2 rounded focus:outline-yellow-500">
            </div>
            <div>
                <label class="block mb-1 font-semibold text-gray-700">Penerbit</label>
                <input type="text" name="publisher" value="{{ $book->publisher }}" required class="w-full border p-2 rounded focus:outline-yellow-500">
            </div>
            <div>
                <label class="block mb-1 font-semibold text-gray-700">Tahun Terbit</label>
                <input type="number" name="year" value="{{ $book->year }}" required class="w-full border p-2 rounded focus:outline-yellow-500">
            </div>
            <div class="flex justify-between items-center pt-2">
                <a href="/books" class="text-gray-600 hover:underline">Batal</a>
                <button type="submit" class="bg-yellow-500 hover:bg-yellow-600 text-white font-semibold px-4 py-2 rounded">
                    Update Data
                </button>
            </div>
        </form>
    </div>
</body>
</html>