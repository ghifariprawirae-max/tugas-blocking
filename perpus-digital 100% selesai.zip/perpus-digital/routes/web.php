<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Models\Book;

Route::get('/', function () {
    return redirect('/books');
});

// 1. Tampil Semua Buku
Route::get('/books', function () {
    $books = Book::all();
    return view('books', compact('books'));
});

// 2. Form Tambah Buku
Route::get('/books/add', function () {
    return view('add-book');
});

// 3. PROSES SIMPAN BUKU BARU (Ini yang membuat /books/store bisa diakses)
Route::post('/books/store', function (Request $request) {
    Book::create([
        'title'     => $request->title,
        'author'    => $request->author,
        'publisher' => $request->publisher,
        'year'      => $request->year,
    ]);
    return redirect('/books');
});

// 4. Form Edit Buku
Route::get('/books/edit/{id}', function ($id) {
    $book = Book::findOrFail($id);
    return view('edit-book', compact('book'));
});

// 5. Proses Update Buku
Route::post('/books/update/{id}', function (Request $request, $id) {
    $book = Book::findOrFail($id);
    $book->update([
        'title'     => $request->title,
        'author'    => $request->author,
        'publisher' => $request->publisher,
        'year'      => $request->year,
    ]);
    return redirect('/books');
});

// 6. Proses Hapus Buku
Route::get('/books/delete/{id}', function ($id) {
    $book = Book::findOrFail($id);
    $book->delete();
    return redirect('/books');
});