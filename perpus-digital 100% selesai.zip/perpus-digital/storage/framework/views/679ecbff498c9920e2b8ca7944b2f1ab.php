<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Buku Baru</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-8">
    <div class="max-w-md mx-auto bg-white p-6 rounded-lg shadow-md">
        <h2 class="text-xl font-bold mb-4 text-blue-600">Tambah Buku Baru</h2>
        
        <form action="/books/store" method="POST" class="space-y-4">
            <?php echo csrf_field(); ?>
            <div>
                <label class="block mb-1 font-semibold text-gray-700">Judul Buku</label>
                <input type="text" name="title" required class="w-full border p-2 rounded focus:outline-blue-500">
            </div>
            <div>
                <label class="block mb-1 font-semibold text-gray-700">Penulis</label>
                <input type="text" name="author" required class="w-full border p-2 rounded focus:outline-blue-500">
            </div>
            <div>
                <label class="block mb-1 font-semibold text-gray-700">Penerbit</label>
                <input type="text" name="publisher" required class="w-full border p-2 rounded focus:outline-blue-500">
            </div>
            <div>
                <label class="block mb-1 font-semibold text-gray-700">Tahun Terbit</label>
                <input type="number" name="year" required class="w-full border p-2 rounded focus:outline-blue-500">
            </div>
            <div class="flex justify-between items-center pt-2">
                <a href="/books" class="text-gray-600 hover:underline">Kembali</a>
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded">
                    Simpan
                </button>
            </div>
        </form>
    </div>
</body>
</html><?php /**PATH D:\xampp\htdocs\perpus-digital\resources\views/add-book.blade.php ENDPATH**/ ?>